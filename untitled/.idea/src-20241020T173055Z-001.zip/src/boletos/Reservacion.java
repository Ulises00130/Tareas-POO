package boletos;

public class Reservacion {

}
