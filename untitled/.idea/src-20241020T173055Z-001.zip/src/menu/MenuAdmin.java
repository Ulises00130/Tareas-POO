package menu;

import cine.Cine;
import usuarios.administrador.Administrador;
import java.util.Scanner;

import java.util.Scanner;

public class MenuAdmin {
    private Scanner scanner = new Scanner(System.in);
    Cine cine = new Cine();

    public boolean loginAdministrador() {
        System.out.println("Iniciar sesión como Administrador");
        System.out.print("Ingrese su ID de administrador: ");
        String id = scanner.nextLine();

        System.out.print("Ingrese su contraseña: ");
        String password = scanner.nextLine();

        // Verifica las credenciales
        for (Administrador administrador : cine.getListaAdministradores()) {
            if (administrador.getId().equals(id) && administrador.getContrasenia().equals(password)) { // Cambiar getContrasenia() a getContrasena()
                System.out.println("Autenticación exitosa. Bienvenido, " + administrador.getNombre());
                return true;
            }
        }
        System.out.println("Error: ID o contraseña incorrectos.");
        return false;
    }

    public void menuAdministrator() {
        // Hacer el login una sola vez antes de mostrar el menú
        boolean autenticado = loginAdministrador();
        if (!autenticado) {
            // Si no se autentica correctamente, salir del método
            return;
        }

        int opcion = 0;
        while (opcion != 4) {
            System.out.println("\nMenú Administrador");
            System.out.println("Seleccione una opción:");
            System.out.println("1. Registrar película: ");
            System.out.println("2. Gestionar salas y asientos: ");
            System.out.println("3. Consultar reservas: ");
            System.out.println("4. Salir: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    System.out.println("Registrar película...");

                    break;
                case 2:
                    cine.asignarSalas();  // Asignar salas y asientos
                    break;
                case 3:
                    // Aquí va el código para consultar reservas
                    System.out.println("Funcionalidad de consultar reservas...");
                    break;
                case 4:
                    System.out.println("Saliendo del menú administrador...");
                    break;
                default:
                    System.out.println("Opción no válida.");
                    break;
            }
        }
    }
}