package menu;

public class MenuCliente {
}
