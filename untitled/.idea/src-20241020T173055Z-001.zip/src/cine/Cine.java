package cine;

import catalogopeliculas.Pelicula;
import salas.Sala;
import usuarios.Usuario;
import usuarios.administrador.Administrador;
import usuarios.utils.Rol;

import java.util.ArrayList;
import java.util.Scanner;

public class Cine {
    public ArrayList <Administrador> listaAdministradores= new ArrayList<>();
    public ArrayList <Pelicula> listaPeliculas= new ArrayList<>();
    public ArrayList <Sala> listaSalas= new ArrayList<>();
    public ArrayList <Usuario> listaUsuarios= new ArrayList<>();
    private static final int MAX_SALAS = 5;
    private Scanner scanner = new Scanner(System.in);
    public Cine (){
        Administrador administrador = new Administrador("272167","Hugo","Perez","123", Rol.ADMINISTRADOR);
        this.listaAdministradores.add(administrador);
        this.listaUsuarios.add(administrador);
    }
    //Cine cine = new Cine();
    public void asignarSalas() {
        Scanner scanner = new Scanner(System.in);

        // Permitir al administrador crear hasta 5 salas
        for (int i = 1; i <= MAX_SALAS; i++) {
            System.out.println("Configurando Sala #" + i);

            // Solicitar el número de filas y columnas para la sala
            System.out.print("Ingrese el número de filas para la sala: ");
            int filas = scanner.nextInt();

            System.out.print("Ingrese el número de columnas para la sala: ");
            int columnas = scanner.nextInt();

            // Crear la sala con las dimensiones especificadas
            Sala nuevaSala = new Sala(i, filas, columnas);

            // Agregar la sala a la lista de salas
            listaSalas.add(nuevaSala);

            System.out.println("Sala #" + i + " configurada con " + filas + " filas y " + columnas + " columnas.");
            System.out.println();
        }
        System.out.println("Se han configurado todas las salas.");
    }

    public ArrayList<Administrador> getListaAdministradores() {
        return listaAdministradores;
    }


    public void setListaAdministradores(ArrayList<Administrador> listaAdministradores) {
        this.listaAdministradores = listaAdministradores;
    }

    public ArrayList<Sala> getListaSalas() {
        return listaSalas;
    }

    public void setListaSalas(ArrayList<Sala> listaSalas) {
        this.listaSalas = listaSalas;
    }

    public ArrayList<Usuario> getListaUsuarios() {
        return listaUsuarios;
    }

    public void setListaUsuarios(ArrayList<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
    }
    public void agregarPelicula(Pelicula pelicula) {
        this.listaPeliculas.add(pelicula);
    }
    public void registrarPelicula() {
        System.out.println("\nRegistro de Película:");

        System.out.print("Ingrese el ID de la película: ");
        String id = scanner.nextLine();

        System.out.print("Ingrese el título de la película: ");
        String titulo = scanner.nextLine();

        System.out.print("Ingrese el género de la película: ");
        String genero = scanner.nextLine();

        System.out.print("Ingrese la clasificación de la película (Ej: PG-13, R, etc.): ");
        String clasificacion = scanner.nextLine();

        System.out.print("Ingrese la duración de la película (en minutos): ");
        int duracion = scanner.nextInt();
        scanner.nextLine(); // Limpiar el buffer

        System.out.print("Ingrese la sinopsis de la película: ");
        String sinopsis = scanner.nextLine();

        // Crear un nuevo objeto Pelicula
        Pelicula nuevaPelicula = new Pelicula(id, titulo, genero, clasificacion, duracion, sinopsis);

        // Añadir la película a la lista en la clase Cine
        agregarPelicula(nuevaPelicula);

        System.out.println("\nPelícula registrada exitosamente:");
        System.out.println(nuevaPelicula);
    }

    public ArrayList<Pelicula> getListaPeliculas() {
        return listaPeliculas;
    }

    public void setListaPeliculas(ArrayList<Pelicula> listaPeliculas) {
        this.listaPeliculas = listaPeliculas;
    }

    public Scanner getScanner() {
        return scanner;
    }

    public void setScanner(Scanner scanner) {
        this.scanner = scanner;
    }
}