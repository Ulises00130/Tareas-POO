package salas;

import catalogopeliculas.Pelicula;
import usuarios.utils.Rol;

import java.time.LocalDate;
import java.time.LocalDateTime;


import java.util.ArrayList;
import java.util.List;

public class Sala {
    private int numeroSala;
    private int capacidad;
    private int filas;
    private int columnas;
    private List<Asiento> asientos;

    public Sala(int numeroSala, int filas, int columnas) {
        this.numeroSala = numeroSala;
        this.filas = filas;
        this.columnas = columnas;
        this.capacidad = filas * columnas;
        this.asientos = new ArrayList<>();
        inicializarAsientos();
    }

    public void setNumeroSala(int numeroSala) {
        this.numeroSala = numeroSala;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getFilas() {
        return filas;
    }

    public void setFilas(int filas) {
        this.filas = filas;
    }

    public int getColumnas() {
        return columnas;
    }

    public void setColumnas(int columnas) {
        this.columnas = columnas;
    }

    public List<Asiento> getAsientos() {
        return asientos;
    }

    public void setAsientos(List<Asiento> asientos) {
        this.asientos = asientos;
    }

    private void inicializarAsientos() {
        for (int fila = 1; fila <= filas; fila++) {
            char letraFila = (char) ('A' + (fila - 1));
            for (int columna = 1; columna <= columnas; columna++) {
                Rol tipoAsiento;
                if (fila <= 2) {
                    tipoAsiento = Rol.VIP;
                } else if (fila <= 4) {
                    tipoAsiento = Rol.PREMIUM;
                } else {
                    tipoAsiento = Rol.NORMAL;
                }

                String idAsiento = letraFila + String.valueOf(columna);
                Asiento asiento = new Asiento(idAsiento, fila, columna, tipoAsiento);
                asientos.add(asiento);  // Agregar asiento a la lista
            }
        }
    }

    // Obtener el estado de todos los asientos en la sala
    public void mostrarEstadoAsientos() {
        for (Asiento asiento : asientos) {
            System.out.println("Asiento ID: " + asiento.getId() + ", Estado: " + asiento.getEstado() + ", Tipo: " + asiento.getTipo() + ", Precio: $" + asiento.getPrecio());
        }
    }

    // Método para reservar un asiento por ID
    public void reservarAsiento(String idAsiento) {
        for (Asiento asiento : asientos) {
            if (asiento.getId().equals(idAsiento)) {
                asiento.reservar();
                return;
            }
        }
        System.out.println("Asiento no encontrado o ya reservado.");
    }


    public int getCapacidad() {
        return capacidad;
    }

    public int getNumeroSala() {
        return numeroSala;
    }

    public int contarAsientosVIP() {
        int count = 0;
        for (Asiento asiento : asientos) {
            if (asiento.getTipo().equals(Rol.VIP)) {
                count++;
            }
        }
        return count;
    }

    public int contarAsientosPremium() {
        int contador = 0;
        for (Asiento asiento : asientos) {
            if (asiento.getTipo().equals(Rol.PREMIUM)) {
                contador++;
            }
        }
        return contador;
    }

    public void mostrarMapaAsientos() {
        System.out.println("Mapa de asientos (D = Disponible, R = Reservado):\n");

        // Recorre las filas
        for (int fila = 1; fila <= filas; fila++) {
            char letraFila = (char) ('A' + (fila - 1));  // Convierte el número de fila a una letra (A, B, C...)

            System.out.print(letraFila + " ");

            for (int columna = 1; columna <= columnas; columna++) {
                String idAsiento = letraFila + String.valueOf(columna);
                Asiento asiento = buscarAsientoPorId(idAsiento);
                if (asiento != null) {
                    // Muestra [D] si el asiento está disponible, [R] si está reservado
                    if (asiento.getEstado().equals("Disponible")) {
                        System.out.print("[D] ");
                    } else {
                        System.out.print("[R] ");
                    }
                }
            }
            System.out.println();
        }
        System.out.println();
    }

    private Asiento buscarAsientoPorId(String idAsiento) {
        for (Asiento asiento : asientos) {
            if (asiento.getId().equals(idAsiento)) {
                return asiento;
            }
        }
        return null;
    }

    public void mostrarDetallesSala(){
        System.out.println("Numero sala: " + this.numeroSala);
        System.out.println("Capacidad: " + this.capacidad);
    }

}

