package usuarios.utils;

public enum Rol {
    CLIENTE,
    ADMINISTRADOR,
    VIP,
    PREMIUM,
    NORMAL
}
